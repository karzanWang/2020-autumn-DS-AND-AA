package lab_two;

class MyQueueEmptyException extends Exception {
    public MyQueueEmptyException(String message) {
        super(message);
    }
}

public class MyQueue<T> {
    private final MyLinkedList<T> queue;

    public MyQueue() {
        queue = new MyLinkedList<>();
    }

    /**
     * todo
     * add a value to the end of the queue
     *
     * @param val a value
     */
    public void enqueue(T val) {

    }

    /**
     * todo
     * get the value at the top (beginning) of the queue, and remove it
     *
     * @return the value
     */
    public T dequeue() throws MyQueueEmptyException {
        return null;
    }

    /**
     * todo
     * get the value at the top (beginning) of the queue, but not remove it
     *
     * @return the value
     */
    public T top() throws MyQueueEmptyException {
        return null;
    }

    /**
     * todo
     *
     * @return size of the queue
     */
    public int size() {
        return 0;
    }

    /**
     * todo
     *
     * @return whether the queue is empty or not
     */
    public boolean isEmpty() {
        return true;
    }

    /**
     * todo
     * Elements will be printed in order
     * May simply call T.toString() method
     *
     * @return the elements in the queue
     */
    @Override
    public String toString() {
        return super.toString();
    }
}
