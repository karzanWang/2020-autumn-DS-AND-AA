# Lab04 BST(Binary Search Tree)

> Chuanwang Wang, Wenqiang Ruan
>
> 19 Oct, 2020

## Introduction

This lab is designed to help you get familiar with Binary Search Tree , a useful data structure .
Your task in this lab is to implement **BST** **individually**.

## Submission

**Deadline**: **In class (100) or 19 Oct 2020 23:59 (60)**. Any uploads after 19 Oct 2020 23:59 will get **ZERO** point.

Create a zip file named **StudentID-StudentName-Lab04.zip** that contains your code project and upload your zip file to **https://wss.pet/s/3q1e1fjdvrg**. Enter **StudentName** in the *Your Name* field.


