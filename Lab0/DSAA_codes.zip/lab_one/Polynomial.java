package lab_one;

public class Polynomial {
    private Term head;

    public Polynomial(Term head) {
        this.head = head;
    }

    public Term getHead() {
        return this.head;
    }

    /**
     * @param head change head
     */
    public void setHead(Term head) {

    }

    /**
     * new term may have same exp with the term in polynomial
     * @param term new term
     */
    public void addTerm(Term term) {

    }

    /**
     * @param another another polynomial
     * @return the sum
     */
    public Polynomial add(Polynomial another) {
        return this;
    }

    /**
     * example: 4.0x^3+3.2x^2-2.1x^1+1.0x^0
     * xample: -12.0x^9-1.0x^7+3.0x^5+10.0x^2+5.0x^0
     * @return a string representing the polynomial
     */
    @Override
    public String toString() {
        return "";
    }

    public static void main(String[] args) {
        /* You can write your test code here,
         * and you can also use junit.
         * */
    }
}
