package lab_two;

class MyStackEmptyException extends Exception {
    public MyStackEmptyException(String message) {
        super(message);
    }
}

public class MyStack<T> {

    private final MyLinkedList<T> stack;

    public MyStack() {
        this.stack = new MyLinkedList<>();
    }

    /**
     * todo
     * add a value to the top of the stack
     * @param val value to be added into the stack
     */
    public void push(T val) {

    }

    /**
     * todo
     * get the value at the top of the stack, and remove it
     * @return the last value added into the stack
     */
    public T pop() throws MyStackEmptyException {
        return null;
    }

    /**
     * todo
     * get the value at the top of the stack, but not remove it
     *
     * @return the last value added into the stack
     */
    public T top() throws MyStackEmptyException {
        return null;
    }

    /**
     * todo
     *
     * @return whether the stack contains any elements or not
     */
    public boolean isEmpty() {
        return true;
    }

    /**
     * todo
     * size of the stack
     *
     * @return size
     */
    public int size() {
        return 0;
    }

    /**
     * todo
     * Elements will be printed in order
     * May simply call T.toString() method
     *
     * @return all elements in the stack
     */
    @Override
    public String toString() {
        return "";
    }
}
