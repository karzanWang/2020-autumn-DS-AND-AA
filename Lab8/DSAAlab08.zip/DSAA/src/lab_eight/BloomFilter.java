package lab_eight;

import java.util.BitSet;

public class BloomFilter {

	//determine the size of bit array
	private int size/* = m*/;
	//determine the number of hash function (different seeds)
	private int[] seeds/* = new int[]{...}*/;
	private BitSet bits = new BitSet(size);

	public BloomFilter() {}

	//add an element to Bloom Filter
	public void add(String str) {

	}

	//query whether Bloom Filter contains the element
	public boolean query(String str) {
		return true;
	}

	//Your hash function
	private int hash(int seed, String str) {
		return 0;
	}
	
}
